# Assets folder

Drop your real photos and videos into this folder using the filenames below.
The site is already wired to look for these exact names — nothing else needs
to change in the code once the files are here.

## Required for the profile photo provision

| Filename                | Used in                          | Recommended size        |
|--------------------------|-----------------------------------|--------------------------|
| `advisor-photo.jpg`      | Header avatar (round) + About section (portrait) | Square or portrait, at least 600×600px, under 500KB |

If this file is missing, the site automatically shows a clean "HC" placeholder
instead of a broken image — so it's safe to deploy before you have the photo
ready, and it will appear automatically the moment you add the file.

## Optional — for the "Photos & Videos" section

That section on the page currently shows dashed placeholder tiles. To replace
them with real content:

1. Add your image files here (e.g. `client-meeting.jpg`, `office.jpg`).
2. Open `index.html`, find the `<section class="media">` block, and replace
   each `<div class="media-tile">...</div>` with an `<img src="assets/your-file.jpg" alt="...">`
   sized via the existing `.media-tile` CSS class (or your own styling).
3. For the video tile, either:
   - Add a short `.mp4` file here and use a `<video controls src="assets/your-video.mp4"></video>` tag, or
   - Embed a YouTube/Vimeo link with an `<iframe>`.

## Image size tips for GitHub Pages

- Keep individual images under ~500KB where possible (compress with
  [squoosh.app](https://squoosh.app) or similar) so the page loads quickly.
- `.jpg` for photos, `.png` only if you need transparency, `.mp4` for video.
